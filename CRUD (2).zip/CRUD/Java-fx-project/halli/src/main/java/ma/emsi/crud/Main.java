package ma.emsi.crud;

import ma.emsi.crud.entities.Employee;
import ma.emsi.crud.service.EmployeeService;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Création d'un objet EmployeeService
        EmployeeService employeeService = new EmployeeService();

        // Test de la méthode insert()
        Employee employee1 = new Employee(1, "John", "Doe", 30, "Manager", 5000);

        employeeService.insert(employee1);
        System.out.println("Employé inséré : " + employee1);

        // Test de la méthode findAll()
        List<Employee> employees = employeeService.findAll();
        System.out.println("Liste des employés :");
        for (Employee employee : employees) {
            System.out.println(employee);
        }

        // Test de la méthode findById()
        int employeeId = 1;
        Employee foundEmployee = employeeService.findById(employeeId);
        if (foundEmployee != null) {
            System.out.println("Employé trouvé avec l'ID " + employeeId + " : " + foundEmployee);
        } else {
            System.out.println("Aucun employé trouvé avec l'ID " + employeeId);
        }

        // Test de la méthode update()
        if (foundEmployee != null) {
            foundEmployee.setSalary(6000);
            employeeService.update(foundEmployee);
            System.out.println("Employé mis à jour : " + foundEmployee);
        }

        // Test de la méthode deleteById()
        int employeeIdToDelete = 1;
        employeeService.deleteById(employeeIdToDelete);
        System.out.println("Employé avec l'ID " + employeeIdToDelete + " supprimé.");

        // Vérification de la liste des employés après suppression
        employees = employeeService.findAll();
        System.out.println("Liste des employés après suppression :");
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }
}

