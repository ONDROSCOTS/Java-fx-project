/*
package ma.emsi.crud.service;

import ma.emsi.crud.entities.Employee;
import ma.emsi.crud.service.EmployeeService;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class File {
    static EmployeeService employeeService = new EmployeeService();

    public static void ImportData(String filepath) {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("Employee");

        List<Employee> listEmployee = employeeService.findAll();

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("id");
        headerRow.createCell(1).setCellValue("firstName");
        headerRow.createCell(2).setCellValue("lastName");
        headerRow.createCell(3).setCellValue("age");
        headerRow.createCell(4).setCellValue("position");
        headerRow.createCell(5).setCellValue("salary");

        int rowNum = 1;
        for (Employee employee : listEmployee) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(employee.getId());
            row.createCell(1).setCellValue(employee.getFirstName());
            row.createCell(2).setCellValue(employee.getLastName());
            row.createCell(3).setCellValue(employee.getAge());
            row.createCell(4).setCellValue(employee.getPosition());
            row.createCell(5).setCellValue(employee.getSalary());
        }

        try (FileOutputStream outputStream = new FileOutputStream(filepath)) {
            workbook.write(outputStream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        System.out.println("Importation des tâches effectuée avec succès");
    }

    public static void ExportData(String filePath) {
        List<Employee> employees = new ArrayList<>();
        try (FileInputStream fileInputStream = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fileInputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

            if (rowIterator.hasNext()) {
                rowIterator.next();
            }

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                String firstName = row.getCell(1).getStringCellValue();
                String lastName = row.getCell(2).getStringCellValue();
                int age = (int) row.getCell(3).getNumericCellValue();
                String position = row.getCell(4).getStringCellValue();
                double salary = row.getCell(5).getNumericCellValue();

                Employee employee = new Employee(firstName, lastName, age, position, salary);
                employees.add(employee);
            }

            for (Employee employee : employees) {
                employeeService.save(employee);
            }
            System.out.println("Exportation des tâches effectuée avec succès");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void ExportJson(String path) {
        List<Employee> employees = employeeService.findAll();
        JSONArray employeesJsonArray = new JSONArray();
        for (Employee employee : employees) {
            JSONObject employeeJson = new JSONObject();
            employeeJson.put("id", employee.getId());
            employeeJson.put("firstName", employee.getFirstName());
            employeeJson.put("lastName", employee.getLastName());
            employeeJson.put("age", employee.getAge());
            employeeJson.put("position", employee.getPosition());
            employeeJson.put("salary", employee.getSalary());
            employeesJsonArray.put(employeeJson);
        }

        String jsonString = employeesJsonArray.toString();
        try (FileWriter fileWriter = new FileWriter(path)) {
            fileWriter.write(jsonString);
            System.out.println("Exportation des tâches en format JSON effectuée avec succès");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void ImportJson(String path) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(path));
        StringBuilder sb = new StringBuilder();
        for (String line : lines) {
            sb.append(line);
        }
        String data = sb.toString();
        String jsonData = data;

        JSONArray employeeArray = new JSONArray(jsonData);

        for (int i = 0; i < employeeArray.length(); i++) {
            JSONObject employeeObj = employeeArray.getJSONObject(i);
            String firstName = employeeObj.getString("firstName");
            String lastName = employeeObj.getString("lastName");
            int age = employeeObj.getInt("age");
            String position = employeeObj.getString("position");
            double salary = employeeObj.getDouble("salary");

            Employee employee = new Employee(firstName, lastName, age, position, salary);
            employeeService.save(employee);
        }

        System.out.println("Importation des tâches au format JSON effectuée avec succès");
    }
}
*/
