package ma.emsi.crud.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import ma.emsi.crud.entities.Employee;
import ma.emsi.crud.service.EmployeeService;

import java.net.URL;
import java.util.ResourceBundle;

public class AddEmployee implements Initializable {
    EmployeeService employeeService = new EmployeeService();
    RedirectController redirectController = new RedirectController();

    @FXML
    private TextField firstName;

    @FXML
    private TextField lastName;

    @FXML
    private TextField age;

    @FXML
    private ComboBox<String> position;

    @FXML
    private TextField salary;

    @FXML
    private Label mess;

    @FXML
    void onReset(ActionEvent event) {
        redirectController.goTo("HomeEmployee.fxml", event);
    }

    @FXML
    void onSubmit(ActionEvent event) {
        String fName = firstName.getText();
        String lName = lastName.getText();
        int empAge = Integer.parseInt(age.getText());
        String empPosition = position.getValue();
        int empSalary = Integer.parseInt(salary.getText());

        if (fName.isBlank() || lName.isBlank() || empPosition == null || empPosition.isBlank()) {
            mess.setText("Informations manquantes");
        } else {
            Employee newEmployee = new Employee(0, fName, lName, empAge, empPosition, empSalary);
            employeeService.insert(newEmployee);
            redirectController.goTo("HomeEmployee.fxml", event);
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }
}
