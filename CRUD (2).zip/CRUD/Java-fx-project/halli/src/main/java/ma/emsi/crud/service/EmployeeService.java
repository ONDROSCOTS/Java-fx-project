package ma.emsi.crud.service;

import ma.emsi.crud.dao.EmployeeDao;
import ma.emsi.crud.dao.impl.EmployeeDaoImpl;
import ma.emsi.crud.entities.Employee;

import java.util.List;

public class EmployeeService {
    final private EmployeeDao employeeDao = new EmployeeDaoImpl();

    public List<Employee> findAll() {
        return employeeDao.findAll();
    }

    public Employee findById(int id) {
        return employeeDao.findById(id);
    }

    public void insert(Employee employee) {
        employeeDao.insert(employee);
    }

    public void update(Employee employee) {
        employeeDao.update(employee);
    }

    public void deleteById(int id) {
        employeeDao.deleteById(id);
    }




}

