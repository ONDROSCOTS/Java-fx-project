package ma.emsi.crud.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import ma.emsi.crud.entities.User;
import ma.emsi.crud.service.UserService;
import ma.emsi.crud.controller.RedirectController;

import java.io.IOException;


public class LoginEmployee {
    RedirectController rc = new RedirectController();
    final private UserService userService = new UserService();
    @FXML
    private Label mess;

    @FXML
    private TextField passwd;

    @FXML
    private Button reset;

    @FXML
    private Button submit;

    @FXML
    private TextField userName;

    @FXML
    void onReset(ActionEvent event) {

    }

    @FXML
    void onSubmit(ActionEvent event)  {
        User user = new User(userName.getText(),passwd.getText());

        boolean testeur = userService.exists(user);
        if(testeur){
            rc.goTo("HomeEmployee.fxml",event);

        }else{
            mess.setText("User name or password incorrect!!");
        }
    }

}
