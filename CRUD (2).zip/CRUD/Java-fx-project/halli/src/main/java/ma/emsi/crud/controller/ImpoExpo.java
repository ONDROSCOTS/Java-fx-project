package ma.emsi.crud.controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import ma.emsi.crud.dataFile.impl.ILoadDataImpl;

import java.io.File;

public class ImpoExpo {
    final private String initialPath = "C:\\Users\\Chouaib\\Documents\\CRUD\\Java-fx-project\\halli\\src\\main\\resources\\dataSource";
    FileChooser fileChooser = new FileChooser();
    RedirectController redirectController = new RedirectController();
    DirectoryChooser directoryChooser = new DirectoryChooser();
    ILoadDataImpl loaddata = new ILoadDataImpl();
    String path;
    @FXML
    void close(ActionEvent event) {
        redirectController.goTo("HomeEmployee.fxml", event);
    }
    @FXML
    void exportExcel(ActionEvent event) {
        String path = getDirPath().concat("\\outputExcel.xlsx");
        loaddata.exportToExcel(path);
    }

    @FXML
    void exportText(ActionEvent event) {
        String path = getDirPath().concat("\\outputText.txt");
        loaddata.exportToText(path);
    }

    @FXML
    void exportTextAsaJSON(ActionEvent event) {
        String path = getDirPath().concat("\\outputJsonAsText.txt");
        loaddata.exportToJSON(path);
    }

    @FXML
    void importExcel(ActionEvent event) {
        path = getFilePath("Excel fille","*.xlsx");
        loaddata.importFromExcel(path);
    }

    @FXML
    void importText(ActionEvent event) {
        path = getFilePath("Text fille","*.txt");
        loaddata.importFromText(path);
    }

    @FXML
    void importTextAsJSON(ActionEvent event) {
        path = getFilePath("Text fille","*.txt");
        loaddata.importFromJSON(path);
    }
    public String getFilePath(String desc,String ext ) {
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter(desc, ext));
        fileChooser.setInitialDirectory(new File(initialPath));
        File file = fileChooser.showOpenDialog(new Stage());
        return file.getPath();
    }

    public String getDirPath(){
        directoryChooser.setInitialDirectory(new File(initialPath));
        String path = directoryChooser.showDialog(new Stage()).getPath();
        return path;
    }

}
