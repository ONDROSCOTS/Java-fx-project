package ma.emsi.crud.dao.impl;

import ma.emsi.crud.entities.Employee;
import ma.emsi.crud.dao.EmployeeDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImpl implements EmployeeDao {
    private Connection conn = DB.getConnection();

    @Override
    public void insert(Employee employee) {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement("INSERT INTO employee (id, firstName, lastName, age, position, salary) VALUES (NULL,?,?,?,?,?)");
            ps.setString(1, employee.getFirstName());
            ps.setString(2, employee.getLastName());
            ps.setInt(3, employee.getAge());
            ps.setString(4, employee.getPosition());
            ps.setInt(5, employee.getSalary());

            int rowsAffected = ps.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Insertion bien faite");
            } else {
                System.out.println("Aucune ligne renvoyée");
            }
        } catch (SQLException e) {
            System.err.println(e.toString());
        } finally {
            DB.closeStatement(ps);
        }
    }

    @Override
    public void update(Employee employee) {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement("UPDATE employee SET firstName=?, lastName=?, age=?, position=?, salary=? WHERE id=?");
            ps.setString(1, employee.getFirstName());
            ps.setString(2, employee.getLastName());
            ps.setInt(3, employee.getAge());
            ps.setString(4, employee.getPosition());
            ps.setInt(5, employee.getSalary());
            ps.setInt(6, employee.getId());

            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Problème de mise à jour d'un employé");
        } finally {
            DB.closeStatement(ps);
        }
    }

    @Override
    public void deleteById(int id) {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement("DELETE FROM employee WHERE id=?");
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Problème de suppression d'un employé");
        } finally {
            DB.closeStatement(ps);
        }
    }

    @Override
    public List<Employee> findAll() {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement("SELECT * FROM employee");
            rs = ps.executeQuery();
            List<Employee> employeeList = new ArrayList<>();
            while (rs.next()) {
                Employee employee = new Employee(
                        rs.getInt("id"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getInt("age"),
                        rs.getString("position"),
                        rs.getInt("salary")
                );
                employeeList.add(employee);
            }
            return employeeList;
        } catch (SQLException e) {
            System.err.println("Problème de requête pour sélectionner les employés");
            return null;
        } finally {
            DB.closeResultSet(rs);
            DB.closeStatement(ps);
        }
    }

    @Override
    public Employee findById(int id) {
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            ps = conn.prepareStatement("SELECT * FROM employee WHERE id=?");
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                Employee employee = new Employee(
                        rs.getInt("id"),
                        rs.getString("firstName"),
                        rs.getString("lastName"),
                        rs.getInt("age"),
                        rs.getString("position"),
                        rs.getInt("salary")
                );
                return employee;
            }
            return null;
        } catch (SQLException e) {
            System.err.println("Problème de requête pour trouver l'employé");
            return null;
        } finally {
            DB.closeResultSet(rs);
            DB.closeStatement(ps);
        }
    }
}

