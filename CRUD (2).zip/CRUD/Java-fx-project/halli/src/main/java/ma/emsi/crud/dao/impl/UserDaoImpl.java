package ma.emsi.crud.dao.impl;

import ma.emsi.crud.dao.UserDao;
import ma.emsi.crud.entities.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {
    private Connection conn = DB.getConnection();
    @Override
    public void newUser(User user) {
        PreparedStatement ps = null;

        try {
            ps = conn.prepareStatement("INSERT INTO User (username, passwd ) VALUES (?,?)");

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPasswd());

            int rowsAffected = ps.executeUpdate(); //? execute la requete

            if (rowsAffected > 0) {
                System.out.println("ligne envoyée");
            } else {
                System.out.println("Aucune ligne renvoyée");
            }
        } catch (SQLException e) {
            System.err.println("problème d'insertion d'un config");;
        } finally {
            DB.closeStatement(ps);
        }
    }

    @Override
    public User getUser(String username) {
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(
                    "SELECT * FROM user WHERE username = ?");

            ps.setString(1, username);
            rs = ps.executeQuery();

            if (rs.next()) {
                User usr = new User(rs.getString("username"), rs.getString("passwd"));
                return usr;
            }
            return null;
        } catch (SQLException e) {
            System.err.println("problème de requête pour trouver l'utilisateur");
            return null;
        } finally {
            DB.closeStatement(ps);
            DB.closeResultSet(rs);
        }
    }

    @Override
    public ArrayList<User> getUsers() {
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(
                    "SELECT * FROM user");
            rs = ps.executeQuery();
            ArrayList<User> list = new ArrayList<>();

            while (rs.next()) {
                list.add(new User(rs.getString("username"),rs.getString("passwd")));
            }

            return list;
        } catch (SQLException e) {
            System.err.println(e);
            return null;
        } finally {
            DB.closeStatement(ps);
            DB.closeResultSet(rs);
        }
    }

    @Override
    public boolean exist(User user) {
        List<User> usrs = getUsers();
        return usrs.contains(user);
    }


}
