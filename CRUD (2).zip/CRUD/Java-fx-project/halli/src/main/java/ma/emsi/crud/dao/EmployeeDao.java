package ma.emsi.crud.dao;

import ma.emsi.crud.entities.Employee;

import java.util.List;

public interface EmployeeDao {
    void insert(Employee employee);
    void update(Employee employee);
    void deleteById(int id);
    List<Employee> findAll();
    Employee findById(int id);
}
