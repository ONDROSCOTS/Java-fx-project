package ma.emsi.crud.dao;

import ma.emsi.crud.entities.User;

import java.util.ArrayList;

public interface UserDao {

    void newUser(User user);

    User getUser(String username);

    ArrayList<User> getUsers();

    boolean exist(User user);

}