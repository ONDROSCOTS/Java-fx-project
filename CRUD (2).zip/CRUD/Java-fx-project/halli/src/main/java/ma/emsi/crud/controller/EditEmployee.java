package ma.emsi.crud.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import ma.emsi.crud.entities.Employee;
import ma.emsi.crud.service.EmployeeService;

import java.net.URL;
import java.util.ResourceBundle;

public class EditEmployee implements Initializable {
    EmployeeService employeeService = new EmployeeService();

    RedirectController redirectController = new RedirectController();


    private int employeeId;

    @FXML
    private TextField firstName;

    @FXML
    private Label mess;

    @FXML
    private TextField lastName;

    @FXML
    private TextField age;

    @FXML
    private ComboBox<String> position;

    @FXML
    private TextField salary;

    public void loadEmployee(Employee employee) {
        employeeId = employee.getId();
        firstName.setText(employee.getFirstName());
        lastName.setText(employee.getLastName());
        age.setText(String.valueOf(employee.getAge()));
        position.setValue(employee.getPosition());
        salary.setText(String.valueOf(employee.getSalary()));
    }

    @FXML
    void onReset(ActionEvent event) {
        redirectController.goTo("HomeEmployee.fxml", event);
    }

    @FXML
    void onSubmit(ActionEvent event) {
        String fName = firstName.getText();
        String lName = lastName.getText();
        int empAge = Integer.parseInt(age.getText());
        String empPosition = position.getValue();
        int empSalary = Integer.parseInt(salary.getText());

        Employee updatedEmployee = new Employee(employeeId, fName, lName, empAge, empPosition, empSalary);
        employeeService.update(updatedEmployee);

        if (fName.isBlank() || lName.isBlank() || empPosition == null || empPosition.isBlank()) {
            mess.setText("Informations manquantes");
        } else {
            Employee newEmployee = new Employee(0, fName, lName, empAge, empPosition, empSalary);
            employeeService.insert(newEmployee);
            redirectController.goTo("HomeEmployee.fxml", event);
        }

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
    }
}
