package ma.emsi.crud.service;

import ma.emsi.crud.dao.UserDao;
import ma.emsi.crud.dao.impl.UserDaoImpl;
import ma.emsi.crud.entities.User;

import java.util.ArrayList;

public class UserService {
    final private UserDao userDao = new UserDaoImpl();

    public ArrayList<User> findAll(){
        return userDao.getUsers();
    }

    public void insert(User user){
        userDao.newUser(user);
    }

    public User getUser(String username){
        return userDao.getUser(username);
    }

    public boolean exists(User user){
        return userDao.exist(user);
    }
}
