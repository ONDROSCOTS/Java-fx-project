package ma.emsi.crud.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import ma.emsi.crud.HelloApplication;
import ma.emsi.crud.entities.Employee;
import ma.emsi.crud.service.EmployeeService;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HomeEmployee implements Initializable {
    RedirectController redirectController = new RedirectController();

    EmployeeService employeeService = new EmployeeService();
    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private TableView<Employee> employeeTable;

    @FXML
    private TableColumn<Employee, String> firstName;

    @FXML
    private TableColumn<Employee, String> lastName;

    @FXML
    private TableColumn<Employee, Integer> age;

    @FXML
    private TableColumn<Employee, String> position;

    @FXML
    private TableColumn<Employee, Double> salary;

    @FXML
    private Label mess;

    ObservableList<Employee> employees = FXCollections.observableArrayList(employeeService.findAll());


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        firstName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        age.setCellValueFactory(new PropertyValueFactory<>("age"));
        position.setCellValueFactory(new PropertyValueFactory<>("position"));
        salary.setCellValueFactory(new PropertyValueFactory<>("salary"));
        employeeTable.setItems(employees);
    }

    @FXML
    void addEmployee(ActionEvent event)  {
        redirectController.goTo("addEmployee.fxml", event);
    }

    @FXML
    void deleteEmployee(ActionEvent event) {
        Employee employee = employeeTable.getSelectionModel().getSelectedItem();
        if (employee == null) {
            mess.setText("Sélectionnez la ligne à supprimer");
        } else {
            mess.setText("  ");
            employeeService.deleteById(employee.getId());
            employeeTable.setItems(FXCollections.observableArrayList(employeeService.findAll()));
            employeeTable.refresh();
        }
    }

    @FXML
    void updateEmployee(ActionEvent event) {
        Employee employee = employeeTable.getSelectionModel().getSelectedItem();
        if (employee == null) {
            mess.setText("Sélectionnez la ligne à modifier");
        } else {
            mess.setText("  ");
            try {
                FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("EditEmployee.fxml"));
                root = loader.load();
                EditEmployee controller = loader.getController();
                controller.loadEmployee(employee);
                stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } catch (IOException exp) {
                System.out.println(exp);
            }
        }
    }

    public void fileEmployee(ActionEvent actionEvent) {
        redirectController.goTo("impoExpoLayout.fxml", actionEvent);

    }
}
