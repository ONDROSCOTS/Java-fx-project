package ma.emsi.crud.dataFile.impl;

import com.google.gson.Gson;
import ma.emsi.crud.entities.Employee;
import ma.emsi.crud.service.EmployeeService;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ILoadDataImpl{
    EmployeeService empService = new EmployeeService();
    static XSSFRow row;

    public void createFile(String path)  {
        File file = new File(path);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        }catch (IOException exp){
            System.out.println(exp);
        }
    }


    public void importFromJSON(String path) {
        try {
            JSONParser parser = new JSONParser();
            Object obj = parser.parse(new FileReader(path));
            JSONObject jsonObject = (JSONObject) obj;
            String jsonObjectList = (String) jsonObject.get("Employee").toString();

            Gson gson = new Gson();
            JSONObject[] empArray = gson.fromJson(jsonObjectList, JSONObject[].class);

            for (int i = 0; i< empArray.length ; i++){
                Employee emp = new Employee(
                         0,
                         empArray[i].get("firstName").toString(),
                         empArray[i].get("lastName").toString(),
                        Integer.valueOf(empArray[i].get("age").toString()),
                        empArray[i].get("position").toString(),
                        Integer.valueOf(empArray[i].get("salary").toString())
                         );
                empService.insert(emp);
            }
        }catch (IOException exp){
            System.out.println(exp);
        }catch (ParseException exp){
            System.out.println(exp);
        }
    }

    public void importFromText(String path)  {
        try{
            File file = new File(path);
            BufferedReader br = new BufferedReader(new FileReader(file));

            List<Employee> list = new ArrayList<>();
            Employee emp = null;
            String readLine = br.readLine();

            while(readLine != null){

                String [] emps  = readLine.split("\\|");

                emp = new Employee();
                emp.setFirstName(emps[0].trim());
                emp.setLastName(emps[1].trim());
                emp.setAge(Integer.valueOf(emps[2].trim()));
                emp.setPosition(emps[3].trim());
                emp.setSalary(Integer.valueOf(emps[4].trim()));

                list.add(emp);
                readLine = br.readLine();
            }
            list.stream().forEach(emps -> empService.insert(emps));

        }catch (IOException exp){
            System.out.println(exp);
        }
    }


    public void importFromExcel(String path) {
        try(FileInputStream fis = new FileInputStream(path))
        {
            XSSFWorkbook workbook = new XSSFWorkbook(fis);
            XSSFSheet spreadsheet = workbook.getSheetAt(0);
            for (int i = 1; i<= spreadsheet.getLastRowNum(); i++){
                row = spreadsheet.getRow(i);
                empService.insert(new Employee(
                        0,
                        row.getCell(0).getStringCellValue(),
                        row.getCell(1).getStringCellValue(),
                        (int) row.getCell(2).getNumericCellValue(),
                        row.getCell(3).getStringCellValue(),
                        (int) row.getCell(4).getNumericCellValue()
                ));
            }
        }
        catch (FileNotFoundException e) {
            System.out.println(e);
        }
        catch (IOException e) {
            System.out.println(e);
        }

    }


    public void exportToJSON(String path) {
        try{
            List list = empService.findAll();
            createFile(path);
            Gson gson = new Gson();
            /*String jsonStr = gson.toJson(list);*/
            BufferedWriter bw = new BufferedWriter(new FileWriter(path));
            list.stream().map(emp ->
                gson.toJson(emp)
            );
            bw.write(list.toString());
            bw.flush();
            bw.close();
        }catch (IOException exp){
            System.out.println(exp);
        }
    }

    public void exportToText(String path) {
        List<Employee> list = empService.findAll();
    try{
        createFile(path);
        FileWriter fileWriter = new FileWriter(path);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        for (Employee emp : list) {
            String string = emp.toString();
            bufferedWriter.write(string);
            bufferedWriter.newLine();
            bufferedWriter.flush();
        }
        System.out.println("Employee exporte bien fait");
        bufferedWriter.close();
    }catch (IOException exp){System.out.println(exp);}

    }

    public void exportToExcel(String path) {
        createFile(path);
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("employee");

        List<Employee> empList;
        empList = empService.findAll();

        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("#");
        headerRow.createCell(1).setCellValue("firstName");
        headerRow.createCell(2).setCellValue("lastName");
        headerRow.createCell(3).setCellValue("age");
        headerRow.createCell(3).setCellValue("position");
        headerRow.createCell(3).setCellValue("salary");

        int rowNum = 1;
        for (Employee emp : empList) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(emp.getFirstName());
            row.createCell(1).setCellValue(emp.getLastName());
            row.createCell(2).setCellValue(emp.getAge());
            row.createCell(2).setCellValue(emp.getPosition());
            row.createCell(2).setCellValue(emp.getSalary());

        }

        try (FileOutputStream outputStream = new FileOutputStream(path)) {
            workbook.write(outputStream);
            System.out.println("Employee exporte bien fait");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
