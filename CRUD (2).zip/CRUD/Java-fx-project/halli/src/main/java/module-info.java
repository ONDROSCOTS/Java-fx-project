module ma.emsi.crud {
    requires javafx.controls;
    requires javafx.fxml;


    requires org.kordamp.bootstrapfx.core;
    requires java.sql;
    requires org.apache.poi.poi;
    requires org.apache.poi.ooxml;
    requires json.simple;
    requires gson;
    requires java.desktop;
/*    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.json;
    requires rt;
    requires jfxrt;*/


    opens ma.emsi.crud to javafx.fxml;
    exports ma.emsi.crud;
    exports ma.emsi.crud.controller;
    opens ma.emsi.crud.controller to javafx.fxml;
    opens ma.emsi.crud.entities to javafx.base;

}